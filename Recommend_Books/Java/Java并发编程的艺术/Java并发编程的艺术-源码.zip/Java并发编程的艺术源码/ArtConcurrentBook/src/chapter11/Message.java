/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package chapter11;

/**
 * 
 * @author tengfei.fangtf
 * @version $Id: Message.java, v 0.1 2015-8-1 ����12:14:46 tengfei.fangtf Exp $
 */
public class Message {

}
