package sia.knights;

public class RescueDamselQuest implements Quest {

  public void embark() {
    System.out.println("Embarking on a quest to rescue the damsel.");
  }

}
