package com.habuma.restfun;

public class MagicBean {

}
