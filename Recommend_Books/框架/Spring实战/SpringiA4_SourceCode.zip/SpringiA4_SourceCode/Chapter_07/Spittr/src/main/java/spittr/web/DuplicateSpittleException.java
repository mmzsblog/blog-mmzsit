package spittr.web;

public class DuplicateSpittleException extends RuntimeException {

}
