package spittr.service;

import spittr.domain.Spittle;

public interface SpittleService {

  public abstract void addSpittle(Spittle spittle);

}